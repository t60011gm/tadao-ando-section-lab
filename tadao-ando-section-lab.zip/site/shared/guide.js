const search=document.querySelector('#search'),count=document.querySelector('#count');
const cards=[...document.querySelectorAll('.card')],buttons=[...document.querySelectorAll('[data-cat]')];
const previewsOnly=document.querySelector('#preview-only');
let category='',only=false;
function filter(){
 const q=search.value.trim().toLowerCase();let visible=0;
 for(const c of cards){c.hidden=Boolean((only&&c.dataset.preview!=='1')||(category&&c.dataset.group!==category)||!c.dataset.search.toLowerCase().includes(q));if(!c.hidden)visible++;}
 const previews=cards.filter(c=>!c.hidden&&c.querySelector('.thumb img:not([hidden])')).length;
 count.textContent=visible+' / '+cards.length+' 個案例 · '+previews+' 個剖面預覽';
}
for(const b of buttons)b.addEventListener('click',()=>{
 category=b.dataset.cat;
 for(const x of buttons){x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',String(x===b));}
 filter();
});
for(const img of document.querySelectorAll('.thumb img')){
 const fail=()=>{img.closest('.card').dataset.preview='0';img.hidden=true;img.nextElementSibling.hidden=false;filter();};
 img.addEventListener('error',fail,{once:true});
 if(img.complete&&img.naturalWidth===0) fail();
}
previewsOnly.addEventListener('click',()=>{only=!only;previewsOnly.setAttribute('aria-pressed',String(only));previewsOnly.classList.toggle('active',only);filter();});
search.addEventListener('input',filter);filter();
